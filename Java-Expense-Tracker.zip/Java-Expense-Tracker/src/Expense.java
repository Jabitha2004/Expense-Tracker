import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

public class Expense {
    private String id;
    private LocalDate date;
    private double amount;
    private String category;
    private String description;

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public Expense(LocalDate date, double amount, String category, String description) {
        this.id = UUID.randomUUID().toString();
        this.date = date;
        this.amount = amount;
        this.category = category;
        this.description = description;
    }

    public Expense(String id, LocalDate date, double amount, String category, String description) {
        this.id = id;
        this.date = date;
        this.amount = amount;
        this.category = category;
        this.description = description;
    }

    public String getId() { return id; }
    public LocalDate getDate() { return date; }
    public double getAmount() { return amount; }
    public String getCategory() { return category; }
    public String getDescription() { return description; }

    public String toCSV() {
        // simple CSV: id,date,amount,category,description (commas in description will be replaced)
        String safeDesc = description.replace(",", " ");
        return String.join(",", id, date.format(FMT), String.format("%.2f", amount), category, safeDesc);
    }

    public static Expense fromCSV(String line) {
        String[] parts = line.split(",", 5);
        if (parts.length < 5) return null;
        String id = parts[0];
        LocalDate date = LocalDate.parse(parts[1], FMT);
        double amount = Double.parseDouble(parts[2]);
        String category = parts[3];
        String description = parts[4];
        return new Expense(id, date, amount, category, description);
    }

    @Override
    public String toString() {
        return String.format("[%s] %s | %.2f | %s | %s", id.substring(0,8), date.format(FMT), amount, category, description);
    }
}