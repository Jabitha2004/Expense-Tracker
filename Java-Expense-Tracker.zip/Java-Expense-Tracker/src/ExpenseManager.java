import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class ExpenseManager {
    private List<Expense> expenses = new ArrayList<>();
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public void addExpense(Expense e) {
        expenses.add(e);
    }

    public List<Expense> listExpenses() {
        // return a copy sorted by date desc
        List<Expense> copy = new ArrayList<>(expenses);
        copy.sort(Comparator.comparing(Expense::getDate).reversed());
        return copy;
    }

    public List<Expense> filterByCategory(String category) {
        List<Expense> res = new ArrayList<>();
        for (Expense e : expenses) {
            if (e.getCategory().equalsIgnoreCase(category)) res.add(e);
        }
        return res;
    }

    public double monthlyTotal(int year, int month) {
        double sum = 0;
        for (Expense e : expenses) {
            if (e.getDate().getYear() == year && e.getDate().getMonthValue() == month) {
                sum += e.getAmount();
            }
        }
        return sum;
    }

    public void saveToCSV(String path) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            for (Expense e : expenses) {
                bw.write(e.toCSV());
                bw.newLine();
            }
        }
    }

    public void loadFromCSV(String path) throws IOException {
        expenses.clear();
        File f = new File(path);
        if (!f.exists()) return;
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line;
            while ((line = br.readLine()) != null) {
                Expense e = Expense.fromCSV(line);
                if (e != null) expenses.add(e);
            }
        }
    }

    public Map<String, Double> categorySummary() {
        Map<String, Double> map = new HashMap<>();
        for (Expense e : expenses) {
            map.put(e.getCategory(), map.getOrDefault(e.getCategory(), 0.0) + e.getAmount());
        }
        return map;
    }
}