import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Main {
    private static final String DATA_FILE = "data/expenses.csv";
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public static void main(String[] args) {
        ExpenseManager mgr = new ExpenseManager();
        try {
            mgr.loadFromCSV(DATA_FILE);
            System.out.println("Loaded existing expenses (if any).");
        } catch (Exception ex) {
            System.out.println("No existing data loaded.");
        }

        Scanner sc = new Scanner(System.in);
        boolean running = true;
        while (running) {
            printMenu();
            String choice = sc.nextLine().trim();
            switch (choice) {
                case "1":
                    addExpenseFlow(sc, mgr);
                    break;
                case "2":
                    listExpensesFlow(mgr);
                    break;
                case "3":
                    summaryFlow(sc, mgr);
                    break;
                case "4":
                    categorySummaryFlow(mgr);
                    break;
                case "5":
                    try {
                        mgr.saveToCSV(DATA_FILE);
                        System.out.println("Saved to " + DATA_FILE);
                    } catch (Exception e) {
                        System.out.println("Failed to save: " + e.getMessage());
                    }
                    break;
                case "0":
                    // save on exit
                    try {
                        mgr.saveToCSV(DATA_FILE);
                        System.out.println("Saved data. Exiting.");
                    } catch (Exception e) {
                        System.out.println("Failed to save on exit: " + e.getMessage());
                    }
                    running = false;
                    break;
                default:
                    System.out.println("Invalid option.");
            }
        }
        sc.close();
    }

    private static void printMenu() {
        System.out.println();
        System.out.println("=== Java Expense Tracker ===");
        System.out.println("1) Add expense");
        System.out.println("2) View all expenses");
        System.out.println("3) Monthly total");
        System.out.println("4) Category summary");
        System.out.println("5) Save now");
        System.out.println("0) Exit");
        System.out.print("Choose: ");
    }

    private static void addExpenseFlow(Scanner sc, ExpenseManager mgr) {
        try {
            System.out.print("Date (yyyy-MM-dd), leave empty for today: ");
            String dateStr = sc.nextLine().trim();
            LocalDate date = dateStr.isEmpty() ? LocalDate.now() : LocalDate.parse(dateStr, FMT);

            System.out.print("Amount (e.g. 250.50): ");
            double amount = Double.parseDouble(sc.nextLine().trim());

            System.out.print("Category (e.g. Food, Travel, Bills): ");
            String category = sc.nextLine().trim();

            System.out.print("Description: ");
            String desc = sc.nextLine().trim();

            Expense e = new Expense(date, amount, category, desc);
            mgr.addExpense(e);
            System.out.println("Added: " + e);
        } catch (Exception ex) {
            System.out.println("Failed to add expense: " + ex.getMessage());
        }
    }

    private static void listExpensesFlow(ExpenseManager mgr) {
        List<Expense> list = mgr.listExpenses();
        if (list.isEmpty()) {
            System.out.println("No expenses recorded.");
            return;
        }
        System.out.println("Recent expenses:");
        for (Expense e : list) {
            System.out.println(e);
        }
    }

    private static void summaryFlow(java.util.Scanner sc, ExpenseManager mgr) {
        try {
            System.out.print("Enter year (e.g. 2024): ");
            int year = Integer.parseInt(sc.nextLine().trim());
            System.out.print("Enter month (1-12): ");
            int month = Integer.parseInt(sc.nextLine().trim());
            double total = mgr.monthlyTotal(year, month);
            System.out.printf("Total for %d-%02d : %.2f\n", year, month, total);
        } catch (Exception ex) {
            System.out.println("Invalid input.");
        }
    }

    private static void categorySummaryFlow(ExpenseManager mgr) {
        Map<String, Double> map = mgr.categorySummary();
        if (map.isEmpty()) {
            System.out.println("No expenses yet.");
            return;
        }
        System.out.println("Category totals:");
        for (Map.Entry<String, Double> e : map.entrySet()) {
            System.out.printf("%s : %.2f\n", e.getKey(), e.getValue());
        }
    }
}