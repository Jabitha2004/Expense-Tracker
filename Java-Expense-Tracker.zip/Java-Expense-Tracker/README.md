# Java Expense Tracker

A beginner-friendly Java console application to track daily expenses.  
Features: add expenses, view list, monthly totals, category summary, save/load CSV.

## How to run

1. Make sure you have JDK installed (Java 8+).
2. From project root, compile:
   ```
   javac -d bin src/*.java
   ```
3. Run:
   ```
   java -cp bin Main
   ```

Data is stored in `data/expenses.csv`.

## Project Structure

```
Java-Expense-Tracker/
 ├── src/
 │    ├── Expense.java
 │    ├── ExpenseManager.java
 │    └── Main.java
 ├── data/
 │    └── expenses.csv
 ├── README.md
```

## Notes
- CSV format: id,date,amount,category,description
- The app replaces commas in descriptions to keep CSV simple.
- Feel free to extend with GUI, JSON import/export, or DB storage.